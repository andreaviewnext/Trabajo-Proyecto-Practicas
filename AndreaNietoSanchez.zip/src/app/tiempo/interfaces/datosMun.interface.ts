export interface DatosMun {
    descripcion: string;
    estado:      number;
    datos:       string;
    metadatos:   string;
}
